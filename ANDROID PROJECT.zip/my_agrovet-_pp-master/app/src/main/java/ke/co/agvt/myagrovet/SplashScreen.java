package ke.co.agvt.myagrovet;

import android.content.Intent;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class SplashScreen extends AppCompatActivity {
    private static int SPLASH_TIME_OUT = 3000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);
        //A Handler allows you communicate back with the UI thread from other background thread
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent openMain = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(openMain);
                finish();
            }
        },SPLASH_TIME_OUT);
    }
}
